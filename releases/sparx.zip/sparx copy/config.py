import pandas as pd


# List of common categories
categories = pd.DataFrame([
	['Agri Science'],
	['Food'],
	['Paper Industries'],
	['Consumer Products'],
	['Others']
], columns=['category'])
