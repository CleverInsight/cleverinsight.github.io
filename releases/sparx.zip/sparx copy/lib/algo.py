import numpy as np 
import scipy.spatial

def squarify(x, y, w, h, data):
    """
        Draw a squarified treemap.
        See <http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.36.6685&rep=rep1&type=pdf>
    
            >>> squarified(0, 0, 6, 4, [6, 6, 4, 3, 2, 2, 1])
            array([[ 0.        ,  0.        ,  3.        ,  2.        ],
                   [ 0.        ,  2.        ,  3.        ,  2.        ],
                   [ 3.        ,  0.        ,  1.71428571,  2.33333333],
                   [ 4.71428571,  0.        ,  1.28571429,  2.33333333],
                   [ 3.        ,  2.33333333,  1.2       ,  1.66666667],
                   [ 4.2       ,  2.33333333,  1.2       ,  1.66666667],
                   [ 5.4       ,  2.33333333,  0.6       ,  1.66666667]])
    
            >>> squarified(0, 0, 1, 1, [np.nan, 0, 1, 2])
            array([[ 0.        ,  0.        ,  0.        ,  0.        ],
                   [ 0.        ,  0.        ,  0.        ,  0.        ],
                   [ 0.        ,  0.        ,  0.33333333,  1.        ],
                   [ 0.33333333,  0.        ,  0.66666667,  1.        ]])
    
        Returns a numpy array with (x, y, w, h) for each item in data.
        """
    (w, h,) = (float(w), float(h))
    size = np.nan_to_num(np.array(data).astype(float))
    (start, end,) = (0, len(size))
    result = np.zeros([end, 4])
    if w <= 0 or h <= 0:
        return result
    cumsize = np.insert(size.cumsum(), 0, 0)
    while start < end:
        (last_aspect, newstart,) = (np.Inf, start + 1)
        startsize = cumsize[start]
        blockmin = blockmax = size[(newstart - 1)]
        blocksum = cumsize[newstart] - startsize
        datasum = cumsize[end] - startsize
        ratio = datasum * (h / w if w > h else w / h)
        while True:
            f = blocksum * blocksum / ratio
            aspect = blockmax / f if blockmax > f else f / blockmax
            aspect2 = blockmin / f if blockmin > f else f / blockmin
            if aspect2 > aspect:
                aspect = aspect2
            if aspect <= last_aspect:
                if newstart < end:
                    last_aspect = aspect
                    newstart += 1
                    val = size[(newstart - 1)]
                    if val < blockmin:
                        blockmin = val
                    if val > blockmax:
                        blockmax = val
                    blocksum += val
                else:
                    break
            else:
                if newstart > start + 1:
                    newstart = newstart - 1
                break

        block = slice(start, newstart)
        blocksum = cumsize[newstart] - startsize
        scale = blocksum / datasum
        blockcumsize = cumsize[block] - startsize
        if w > h:
            r = h / blocksum
            result[block, 0] = x
            result[block, 1] = y + r * blockcumsize
            result[block, 2] = dx = w * scale
            result[block, 3] = r * size[block]
            (x, w,) = (x + dx, w - dx)
        else:
            r = w / blocksum
            result[block, 0] = x + r * blockcumsize
            result[block, 1] = y
            result[block, 2] = r * size[block]
            result[block, 3] = dy = h * scale
            (y, h,) = (y + dy, h - dy)
        start = newstart

    return np.nan_to_num(result)


class Squarified:
    """
    
        Draws a generic squarified treemap.
        See <http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.36.6685&rep=rep1&type=pdf>
    
        Usage:
    
            import treemap
            tm = treemap.Squarified(x=0, y=0, width=100, height=100,
                                    data=[1,2,3,4,5])
            for x, y, width, height, value in tm.draw():
                # ...
        """


    def __init__(self, x, y, width, height, data, size = lambda x: x, children = lambda x: None, padding = 0.0):
        self.x = x
        self.y = y
        self.pad = padding
        self.data = data
        self.size = lambda v: np.nan_to_num(float(size(v)))
        self.children = children
        width = max(width, 0)
        height = max(height, 0)
        self.scale = (float(width * height) / (sum((self.size(v) for v in data)) or 1)) ** 0.5
        self.width = np.divide(float(width), self.scale)
        self.height = np.divide(float(height), self.scale)



    def draw(self):
        if self.scale > 0:
            for box in self._squarify(self.data, [], min(self.width, self.height)):
                yield box




    def _squarify(self, tree, row, w):
        if len(tree) == 0:
            if row:
                for box in self._layoutrow(row):
                    yield box

            return 
        row_with_first_child = row + [tree[0]]
        if not row or self._worst_aspect_ratio(row, w) > self._worst_aspect_ratio(row_with_first_child, w):
            for box in self._squarify(tree[1:], row_with_first_child, w):
                yield box

        else:
            for box in self._layoutrow(row):
                yield box

            for box in self._squarify(tree, [], min(self.height, self.width)):
                yield box




    def _worst_aspect_ratio(self, row, w):
        sizes = [ self.size(v) for v in row ]
        s = sum(sizes)
        m = max(sizes)
        return max(np.divide(w * w * m, s * s), np.divide(s * s, w * w * m))



    def _layoutrow(self, row):
        if self.width >= self.height:
            step = (sum((self.size(v) for v in row)) or 1) / self.height
            y = self.y
            for v in row:
                children = self.children(v)
                if children is not None and len(children) > 0:
                    (w, h,) = (self.scale * step, self.scale * self.size(v) / step)
                    tm = self.__class__(self.x + self.pad, y + self.pad, w - 2 * self.pad, h - 2 * self.pad, children, self.size, self.children, self.scale * self.pad)
                    for box in tm.draw():
                        yield box

                else:
                    yield (self.x,
                     y,
                     self.scale * step,
                     self.scale * self.size(v) / step,
                     v)
                y += self.scale * self.size(v) / step

            self.x += step * self.scale
            self.width -= step
        else:
            step = (sum((self.size(v) for v in row)) or 1) / self.width
            x = self.x
            for v in row:
                children = self.children(v)
                if children is not None and len(children) > 0:
                    (w, h,) = (self.scale * self.size(v) / step, self.scale * step)
                    tm = self.__class__(x + self.pad, self.y + self.pad, w - 2 * self.pad, h - 2 * self.pad, children, self.size, self.children, self.scale * self.pad)
                    for box in tm.draw():
                        yield box

                else:
                    yield (x,
                     self.y,
                     self.scale * self.size(v) / step,
                     self.scale * step,
                     v)
                x += self.scale * self.size(v) / step

            self.y += step * self.scale
            self.height -= step

