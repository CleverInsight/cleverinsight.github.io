from __future__ import division
import numpy as np 
import pandas as pd
from .svg import SVG
from .algo import squarify
from .color import gradient



class Treemap:

	def __init__(self):
		pass

	@staticmethod
	def draw(element, w, h, size_values, label_values, color_values ,  text=True):

		"""
			https://github.com/petercollingridge/DrawSVG
			Prepare the svg element for treemap using squarify algorithm
			>>>  squarify(0, 0, 10, 20, [10, 7, 5, 3, 2, 2, 1, 1])
			- Create the SVG Element with classs element
			- Iterate the array and create g tag with rect and text
			- Return the completely formed SVG
		"""
		data = squarify(0, 0, w, h, size_values)
		svg = SVG(element, w, h)

		_min = np.amin(color_values)
		_mean = np.mean(color_values)
		_max = np.amax(color_values)
		for (i, (x, y, width, height)) in enumerate(data):
			H = max(4, min(width/6, height/3))
			svg.addChildElement('rect', {'x':'%0.2f' %x,\
			 	 'y':'%0.2f' %y, 'width':width, 'height':height,\
			 	 'fill': gradient(color_values[i], ((_min, '#ff0000'), (_mean, '#ffff00'), (_max, '#4CAF50'))),
			 	 'stroke': '#fff'})

			if text:
				svg.addChildElement('text', {'x':x + width/2, 'y':y + height / 2 - H / 2,\
				 'dominant-baseline': 'middle', 'text-anchor': 'middle', 'font-family':'monospace',\
				 'data-toggle': 'tooltip', 'data-placement':'right',\
				 'font-size': H, 'fill': '#000', 'title': str(label_values[i])}, str(label_values[i]))

		return svg.output()



class Bar:

	def __init__(self):
		pass

	@staticmethod
	def draw(element, x, y, w, values):
		"""
			w is the total width of svg
			h is the total height of svg which should be higher than values max
			x is the starting X coordinates
			y is the starting Y coordinates
			values is an array of numbers
			values = np.asarray(values)

			h = max(values)
			total_element = len(values)
		"""
		values = np.asarray(values)
		_min = np.amin(values)
		_mean = np.mean(values)
		_max = np.amax(values)

		width = w/values.size
		h = np.amax(values)

		svg = SVG(element, w, h)



		for i in range(values.size):

			x = (width*i) + 2
			svg.addChildElement('rect', {'x':'%0.2f' %x,\
			 	 'y':'%0.2f' %(h - values[i]), 'width':width, 'height':values[i],\
			 	 'fill': gradient(values[i], ((_min, '#ff0000'), (_mean, '#ffff00'), (_max, '#4CAF50'))),
			 	 'stroke': '#fff'})

			svg.addChildElement('text', {'x':x + (width/2), 'y':((h + 10) - values[i]),\
			 'dominant-baseline': 'middle', 'text-anchor': 'middle', 'font-family':'monospace',\
			 'data-toggle': 'tooltip', 'data-placement':'right',\
			 'font-size': (width/2) , 'fill': '#000'}, str(int(values[i])))

		return svg.output()




			
	


class HeatGrid:

	def __init__(self):
		pass

	def draw():
		pass