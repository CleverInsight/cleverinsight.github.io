"""
	Module: Machine Learning Models
	Project: LitmusBi Brain
	Author: Bastin Robins. J
	Email : robin@hashresearch.com
"""
import os
import pickle
import numpy as np
from sklearn import tree
from sklearn.metrics import accuracy_score
from sklearn.cross_validation import train_test_split


class ML:
	def __init__(self):
		self.version = 0.1
		self.author = "Bastin Robins.J"
		self.memory = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'memory')

	def preformat_txt(self, path):
		""" Preformat the .txt training dataset """
		return np.genfromtxt(path, delimiter=',', dtype=int)

	def split_train_test(self, _data, test_size):
		"""
			Split the give _data into the following
			X_train, X_test, Y_train, Y_test
		"""
		_features = [x[1:10] for x in _data]
		_labels = [x[10] for x in _data]
		return train_test_split(_features, _labels, test_size = test_size)


	def train_classifier(self, features, labels):
		""" Train the classifier with the preformated training dataset """
		_clf = tree.DecisionTreeClassifier()
		_clf = _clf.fit(features, labels)
		return _clf

	def train_save_classifier(self, path, save_as):
		""" Train the classifier and save into pickle and returns current clf"""
		_data = self.preformat_txt(path)
		_features = [x[1:10] for x in _data]
		_labels = [x[10] for x in _data]

		_clf = tree.DecisionTreeClassifier()
		_clf = _clf.fit(_features, _labels)
		save_as = os.path.join(self.memory, (save_as) + '.pickle')
		with open(save_as, 'wb') as f:
			pickle.dump(_clf, f)
		return _clf


	def load_trained_classifier(self, open_as):
		open_as = os.path.join(self.memory, (open_as) + '.pickle')
		pickle_in = open(open_as, 'rb')
		_clf = pickle.load(pickle_in)
		return _clf


	def predict(self, path, features):
		_data = self.preformat_txt(path)
		X_train, X_test, Y_train, Y_test = self.split_train_test(_data, 0.1)
		clf = self.train_classifier(X_train, Y_train)
		prediction = clf.predict(X_test)
		return [prediction, accuracy_score(Y_test, prediction) * 100]
