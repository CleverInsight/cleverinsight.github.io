import re
import os
import sys
# import LatLon
import sqlite3
import pandas as pd
import numpy as np
# from LatLon import string2latlon
# from torndb import Connection

class Litmus:

    version = "0.1.0"


    def __init__(self):
        # Configuration settings
        self.__HOST__     = "localhost" 
        self.__USER__     = "root"
        self.__PASSWORD__ = "testers.w3"
        self.__DB__       = "litmus_api"


    def connect(self):
        """ Establish connection to mysql database """
        return Connection(self.__HOST__, self.__DB__, user=self.__USER__, password=self.__PASSWORD__)

    def get_query_string(self, url):
        """ Convert url query string into dictionary """
        return json.dumps(urlparse.parse_qs(url))


    def get_csv(self, path, filename):
        """ Read csv file and return pandas dataframes """
        return pd.read_csv(path + filename, parse_dates=True)


    def get_column_names(self, dframe):
        """ Takes dataframes as input and return column names as Litmus """
        return dframe.columns.tolist()

    def convert_dataframe_dict(self, dframe):
        """
        Takes the dataframe as input convert into dictionary with
        keys as column name and unique column values as list
        for eg: {'State':['Tamilnadu', Kerala], 'Category': ['Total Income'] }
        """
        response = {}
        for column in dframe.columns.values.tolist():
            response[column] = list(set(dframe[column]))
        return response

    def clean_keys(self, data):
        """ Removes the [] from the python dictionary by replace method """
        t = {}
        for k, v in data.items():
            t[k.replace('[]', '')] = v
        return t


    def _execute(self, query):

        dbPath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sys.db')
        connection = sqlite3.connect(dbPath)
        cursorobj = connection.cursor()
        try:
                cursorobj.execute(query)
                result = cursorobj.fetchall()
                connection.commit()
        except Exception:
                raise
        connection.close()
        return result


    def _query(self, query, keyword):
        dbPath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sys.db')
        connection = sqlite3.connect(dbPath)
        cursorobj = connection.cursor()
        try:
                cursorobj.execute(query, keyword)
                result = cursorobj.fetchall()
                connection.commit()
        except Exception:
                raise
        connection.close()
        return result

    def dict_factory(self, cursor, row):
        d = {}
        for idx, col in enumerate(cursor.description):
            d[col[0]] = row[idx]
        return d

    def _get(self, query):
        dbPath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sys.db')
        connection = sqlite3.connect(dbPath)
        connection.row_factory = self.dict_factory
        cursorobj = connection.cursor()
        cursorobj.execute(query)
        return cursorobj.fetchone()


    def _set(self, query, values):
        dbPath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sys.db')
        connection = sqlite3.connect(dbPath)
        cursorobj = connection.cursor()
        try:
                cursorobj.execute(query, values)
                result = cursorobj.lastrowid
                connection.commit()
        except Exception:
                raise
        connection.close()
        return result



    def get_lat(self, lat, lon):
        """ 
        Takes Coordinate and return latitude in decimals
        """
        lat = re.sub('[^A-Za-z0-9\.]+', ' ', lat)
        lon = re.sub('[^A-Za-z0-9\.]+', ' ', lon)
        return string2latlon(lat, lon, 'd% %m% %S% %H').to_string()[0]


    def get_lng(self, lat, lon):
        """ 
        Takes Coordinate and return longitude in decimals
        """
        lat = re.sub('[^A-Za-z0-9\.]+', ' ', lat)
        lon = re.sub('[^A-Za-z0-9\.]+', ' ', lon)
        return string2latlon(lat, lon, 'd% %m% %S% %H').to_string()[1]
