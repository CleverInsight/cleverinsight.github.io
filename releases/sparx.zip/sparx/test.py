# # import os
# # # print os.path.join(os.path.dirname(os.path.abspath(__file__)), 'storage/')
# # import sys

# # from lib.litmus import *

# # l = Litmus()
# # print l._insert('hello')
# # 
# import pandas as pd
# import numpy as np
# from lib.data import *
# def squarified(x, y, w, h, data):
#     """
#         Draw a squarified treemap.
#         See <http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.36.6685&rep=rep1&type=pdf>
    
#             >>> squarified(0, 0, 6, 4, [6, 6, 4, 3, 2, 2, 1])
#             array([[ 0.        ,  0.        ,  3.        ,  2.        ],
#                    [ 0.        ,  2.        ,  3.        ,  2.        ],
#                    [ 3.        ,  0.        ,  1.71428571,  2.33333333],
#                    [ 4.71428571,  0.        ,  1.28571429,  2.33333333],
#                    [ 3.        ,  2.33333333,  1.2       ,  1.66666667],
#                    [ 4.2       ,  2.33333333,  1.2       ,  1.66666667],
#                    [ 5.4       ,  2.33333333,  0.6       ,  1.66666667]])
    
#             >>> squarified(0, 0, 1, 1, [np.nan, 0, 1, 2])
#             array([[ 0.        ,  0.        ,  0.        ,  0.        ],
#                    [ 0.        ,  0.        ,  0.        ,  0.        ],
#                    [ 0.        ,  0.        ,  0.33333333,  1.        ],
#                    [ 0.33333333,  0.        ,  0.66666667,  1.        ]])
    
#         Returns a numpy array with (x, y, w, h) for each item in data.
#         """
#     (w, h,) = (float(w), float(h))
#     size = np.nan_to_num(np.array(data).astype(float))
#     (start, end,) = (0, len(size))
#     result = np.zeros([end, 4])
#     if w <= 0 or h <= 0:
#         return result
#     cumsize = np.insert(size.cumsum(), 0, 0)
#     while start < end:
#         (last_aspect, newstart,) = (np.Inf, start + 1)
#         startsize = cumsize[start]
#         blockmin = blockmax = size[(newstart - 1)]
#         blocksum = cumsize[newstart] - startsize
#         datasum = cumsize[end] - startsize
#         ratio = datasum * (h / w if w > h else w / h)
#         while True:
#             f = blocksum * blocksum / ratio
#             aspect = blockmax / f if blockmax > f else f / blockmax
#             aspect2 = blockmin / f if blockmin > f else f / blockmin
#             if aspect2 > aspect:
#                 aspect = aspect2
#             if aspect <= last_aspect:
#                 if newstart < end:
#                     last_aspect = aspect
#                     newstart += 1
#                     val = size[(newstart - 1)]
#                     if val < blockmin:
#                         blockmin = val
#                     if val > blockmax:
#                         blockmax = val
#                     blocksum += val
#                 else:
#                     break
#             else:
#                 if newstart > start + 1:
#                     newstart = newstart - 1
#                 break

#         block = slice(start, newstart)
#         blocksum = cumsize[newstart] - startsize
#         scale = blocksum / datasum
#         blockcumsize = cumsize[block] - startsize
#         if w > h:
#             r = h / blocksum
#             result[block, 0] = x
#             result[block, 1] = y + r * blockcumsize
#             result[block, 2] = dx = w * scale
#             result[block, 3] = r * size[block]
#             (x, w,) = (x + dx, w - dx)
#         else:
#             r = w / blocksum
#             result[block, 0] = x + r * blockcumsize
#             result[block, 1] = y
#             result[block, 2] = r * size[block]
#             result[block, 3] = dy = h * scale
#             (y, h,) = (y + dy, h - dy)
#         start = newstart

#     return np.nan_to_num(result)
# # print squarified(0, 0, 700, 600, [100,200,300,500,10,600])
# # 

# df = pd.read_csv('/media/Work/hashresearch/LitmusBi-Server/storage/Growth data_07 JUNE 2016.csv')

# # df = df[(df['Clone No'] == 'B5')]

# # for key, values in df.iloc[[0]].iteritems():
# #     print df.iloc[[0]][key].values[0]

# d = DataStore()
# 
# 
# f = open('storage/downloads/exodxcvneuvy.pdf', 'r')
# print f.readlines()
# DB = DataStore()

# print DB.csv('Growth.csv')


# class DB:

# 	def __init__(self):
# 		self.source = '/media/bastinrobin'
# 		self.data = dict()

# 	def __setitem__(self, key, value):
# 		self.data[key] = value

# 	def __getitem__(self, key):
# 		return self.data[key]

# 	def csv(self, filename):
# 		self[filename] = filename
# 		return self[filename]



# d = DB()
# print d.csv('simple.py')
# Import Supervised Learning Models
from lib.brain import supervised