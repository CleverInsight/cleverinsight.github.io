"""
    Module: Machine Learning Models
    Project: NeuronAi
    Author: Bastin Robins. J
    Email : robin@cleverinsight.com
"""
import os
import pickle
import numpy as np
import pandas as pd 
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import make_moons, make_circles, make_classification
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis

MEMORY = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'memory')


# Algorithms Hashtable
ML = {
    'classification' : [
        {'name': 'Decision Tree', 'model': DecisionTreeClassifier(max_depth=5) },
        {'name': 'Nearest Neighbors', 'model': KNeighborsClassifier(3) },
        {'name': 'Linear SVM', 'model': SVC(kernel="linear", C=0.025) },
        {'name': 'RBF SVM', 'model': SVC(gamma=2, C=1) },
        {'name': 'Gaussian Process', 'model': GaussianProcessClassifier(1.0 * RBF(1.0), warm_start=True) },
        {'name': 'Random Forest', 'model': RandomForestClassifier(max_depth=5, n_estimators=10, max_features=1) },
        {'name': 'Neural Net', 'model': MLPClassifier(alpha=1) },
        {'name': 'AdaBoost', 'model': AdaBoostClassifier() },
        {'name': 'Naive Bayes', 'model': GaussianNB() },
        {'name': 'QDA', 'model': QuadraticDiscriminantAnalysis() }
    ],
    'regression': [
        {'name': 'LinearRegression'},
        {'name': 'RidgeRegression'},
        {'name': 'LassoRegression'},
        {'name': 'RandomForestRegressor'},
        {'name': 'SVR'}
    ]
}


class Preprocess:

    def __init__(self):
        self.version = (0,0,1)


    def find_relevant_model(self, feature):
        """ Return relevant model for the given 
        feature type
        """
        return ML[feature]


    def get_response_type(self, feature):
        """ Take a column in dataframe called features
        and return the type of machine learning problem
        Eg: obj and int = classification
            float64 = regression
            int64 with count 2 = logistic regression
        """
        if feature.dtypes == 'float64':
            return 'regression'

        if feature.dtypes == 'object' or feature.dtypes == 'int64':
            return 'classification'



    def get_response_model(self, feature):
        """ Take a column in dataframe called features
        and return the type of machine learning model
        """
        if feature.dtypes == 'float64':
            return find_relevant_model('regression')

        if feature.dtypes == 'object' or feature.dtypes == 'int64':
            return find_relevant_model('classification')


    def get_response_model_names(self, feature):

        if feature.dtypes == 'float64':
            return [{'name' : 'LinearRegression'}, {'name': 'RidgeRegression'}, \
            {'name' : 'LassoRegression'},{'name': 'RandomForestRegressor'}, {'name' : 'SVR'}]

        if feature.dtypes == 'object' or feature.dtypes == 'int64':
            return [{'name' : "Nearest Neighbors"}, {'name' : "Linear SVM"}, {'name' : "RBF SVM"},\
            {'name' : "Gaussian Process"}, {'name' : "Decision Tree"}, {'name' : "Random Forest"},\
            {'name' : "Neural Net"}, {'name' : "AdaBoost"}, {'name' : "Naive Bayes"}, {'name' : "QDA"}]



class supervised:

    def __init__(self):
        self.version = (0,0,1)
        self.author = "Bastin Robins J"
        self.email = "robin@hashresearch.com"
        self.memory = MEMORY


    # Decision Tree Classifier
    def dt(self):
        from sklearn import tree
        return tree.DecisionTreeClassifier()

    # KNN Classifier
    def knn(self):
        from sklearn.neighbors import KNeighborsClassifier
        return KNeighborsClassifier()

    # Regression
    def linear_regression(self):
        from sklearn import linear_model
        return linear_model.LinearRegression()
