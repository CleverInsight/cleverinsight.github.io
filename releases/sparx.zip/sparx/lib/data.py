import os
import sys
import pickle
import stat
import pandas as pd
import numpy as np
import sqlite3
import hashlib
from collections import MutableMapping

_none = lambda v: v

class DataStore:

    def __init__(self):
        # Depreciated in favour of app_source
        self.source = os.path.abspath(os.path.join(os.path.dirname( __file__ ),\
            '..', 'storage'))

        self.data = dict()

        self.app_source = os.path.join(os.getcwd(), 'apps')



    def __setitem__(self, key, value):
        self.data[key] = value

    def __getitem__(self, key):
        return self.data[key]

    # Depreciated in favour of load
    def csv(self, filename, setup = _none, **csv_args):
        """
                Loads a CSV file as a DataFrame, persists it in memory across pages.
        
                path:
                    Loads CSV file at path.
              
                setup:
                    A function that takes the CSV as a dataframe, performs
                    a one-time setup, and *returns* the dataframe.
                csv_args:
                    Any other arguments (like separator=) are passed directy
                    to pd.read_csv
                """
        path = os.path.join(self.source, filename)

        if os.path.exists(path):
            self[filename] = setup(pd.read_csv(path, **csv_args)) 
            return self[filename]
        else:
            return "File doesn't exists"


    def load(self, filename, setup = _none, **csv_args):
        """
        Loads a CSV file as a DataFrame, persists it in memory across pages.

        path:
            Loads CSV file at path.
      
        setup:
            A function that takes the CSV as a dataframe, performs
            a one-time setup, and *returns* the dataframe.
        csv_args:
            Any other arguments (like separator=) are passed directy
            to pd.read_csv
        """
        path = os.path.join(self.app_source, filename)

        if os.path.exists(path):
            self[filename] = setup(pd.read_csv(path, **csv_args)) 
            return self[filename]
        else:
            return "File doesn't exists"