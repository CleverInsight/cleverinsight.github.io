import re
import operator
import numpy as np
import colorsys

def rgba(color):
    """Follows <http://dev.w3.org/csswg/css3-color/> and returns a [0-1] float for rgba"""
    result = []
    if color.startswith('#'):
        if len(color) == 7:
            result = [int(color[1:3], 16) / 255.0, int(color[3:5], 16) / 255.0, int(color[5:7], 16) / 255.0]
        elif len(color) == 4:
            result = [int(color[1:2], 16) / 15.0, int(color[2:3], 16) / 15.0, int(color[3:4], 16) / 15.0]
        else:
            result = []
    elif color.startswith('rgb(') or color.startswith('rgba('):
        for (i, v,) in enumerate(re.findall('[0-9\\.%]+', color.split('(')[1])):
            if v.endswith('%'):
                result.append(float(v[:-1]) / 100)
            elif i < 3:
                result.append(float(v) / 255.0)
            else:
                result.append(float(v))

    elif color.startswith('hsl(') or color.startswith('hsla('):
        for (i, v,) in enumerate(re.findall('[0-9\\.%]+', color.split('(')[1])):
            if v.endswith('%'):
                result.append(float(v[:-1]) / 100)
            elif i == 0:
                result.append(float(v) / 360 % 1)
            else:
                result.append(float(v))

        (result[0], result[1], result[2],) = colorsys.hsv_to_rgb(result[0], result[1], result[2])
    elif color in _colornames:
        result = _colornames[color]
    if len(result) == 3:
        result.append(1.0)
    if len(result) != 4:
        raise ValueError('%s: invalid color' % color)
    return tuple((0 if v < 0 else 1 if v > 1 else v for v in result))


def _name(r, g, b, a = 1):
    """Returns a short color string"""
    r = 0 if r < 0 else 1 if r > 1 else r
    g = 0 if g < 0 else 1 if g > 1 else g
    b = 0 if b < 0 else 1 if b > 1 else b
    a = 0 if a < 0 else 1 if a > 1 else a
    if a >= 1:
        # s = '#%02x%02x%02x' % (255 * r, 255 * g, 255 * b)
        s = ''.join('%02x'%int(i) for i in [255 * r, 255 * g, 255 * b])
        s = '#' + s
        return re.sub('#(\\w)\\1(\\w)\\2(\\w)\\3', '#\\1\\2\\3', s)
    else:
        return 'rgba(%d,%d,%d,%0.2f)' % (255 * r,
         255 * g,
         255 * b,
         a)



def gradient(x, ranges, opacity = 1):
    """
        Sample usage:
    
            gradient(0.4, ((-1, '#ff0000'), (0, '#ffffff'), (1, '#00ff00')))
    
        interpolates 0.4 between -1 - 0 - +1 and returns an in-between color
        as #RRGGBB
    
        The value `x` can also be an array (or any other iterable).
    
        An optional opacity attribute, if passed, is returned with all colours.
        """
    # if np.ndim(x) > 0:
    #     return [ gradient(v, ranges) for v in x ]
    x = float(x) if not np.isnan(x) else 0
    ranges = sorted(ranges, key=operator.itemgetter(0))
    if x <= ranges[0][0]:
        return ranges[0][1]
    if x >= ranges[-1][0]:
        return ranges[-1][1]
    for (i, (start, color,),) in enumerate(ranges):
        if x <= start:
            break

    p = (x - ranges[(i - 1)][0]) / (ranges[i][0] - ranges[(i - 1)][0])
    q = 1.0 - p
    a = rgba(ranges[(i - 1)][1])
    b = rgba(ranges[i][1])
    return _name(a[0] * q + b[0] * p, a[1] * q + b[1] * p, a[2] * q + b[2] * p, opacity)
