import os
import sys
import rsa
import base64
import socket
import platform

SOURCE = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.join(SOURCE, 'LICENSE')

def verify(_path):

    uname = ' '.join(platform.uname())

    def run():
        import tornado.web
        import tornado.ioloop

        template = os.path.abspath(os.path.join(os.path.dirname( __file__ ), '..', 'visuals'))
        static = os.path.abspath(os.path.join(os.path.dirname( __file__ ), '..', 'static'))

        class LicenseHandler(tornado.web.RequestHandler):
            def get(self):
                self.render('license.html', version='version')

        app = tornado.web.Application([('/', LicenseHandler)],
            static_path=static,
            template_path=template
        )
        
        port = 8888
        while port < 9000:
            try:
                app.listen(port, xheaders=True)
                break
            except socket.error:
                port += 1

        print sys.stderr

        url = 'http://127.0.0.1:%d' % port
        try:
            import webbrowser
            print 'Visit ' + url + ' for a license '
            webbrowser.open(url)
        except ImportError:
            pass

        tornado.ioloop.IOLoop.instance().start()

    def die(msg):
        sys.stderr.write(msg)
        sys.stderr.write('\n\nYou should email license@hashresearch.com and get a new license. Mention this code:\n%s\n\n' % uname)
        sys.stderr.write('... and save the LICENSE file you get at:\n%s\n\n' % _path)
        # sys.exit(-1)
        run()


    try:
        license_file = os.path.join(_path, 'LICENSE')
        license_lines = open(license_file).readlines()
    except IOError:
        die('This machine does not have a license yet.')

    (license_uname, license_date, sign,) = (l.strip() for l in license_lines[:3])

    if uname != license_uname:
        die("This machine has another machine's license:\n" + license_uname)

    (from_date, to_date,) = (datetime.datetime.strptime(d, '%Y-%m-%d') for d in license_date.split(' '))
    now = datetime.datetime.now()

    if from_date > now or now > to_date:
        die('This license has expired.')

    public_key = rsa.PublicKey(7536031843268116359080816550116996395850668765953362202458977259126858121692866095588080612658209610356308429486462330553891865314861527172133866282508997, 65537)

    try:
        rsa.verify(uname + license_date, base64.b64decode(sign), public_key)
    except:
        die('The license appears invalid.')



verify(PATH)