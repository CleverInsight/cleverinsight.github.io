"""
    Module: Machine Learning Models
    Project: LitmusBi Brain
    Author: Bastin Robins. J
    Email : robin@hashresearch.com
"""
import os
import pickle
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.cross_validation import train_test_split

MEMORY = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'memory')




class Supervised:
    """ Supervised Machine Learning Models belongs to this class"""
    def __init__(self):
        self.version = (0,0,1)
        self.author = "Bastin Robins"
        self.email = "robin@hashresearch.com"
        self.memory = MEMORY

    # Decision Tree Classifier
    def decision_tree(self):
        from sklearn import tree
        return tree.DecisionTreeClassifier()

    # KNN Classifier
    def kn_neighbour(self):
        from sklearn.neighbors import KNeighborsClassifier
        return KNeighborsClassifier()

    # Regression
    def linear_regression(self):
        from sklearn import linear_model
        return linear_model.LinearRegression()

    # Logistic Regression
    # Random Forest Classifier


clf = Supervised()
print clf.linear_regression()


# Pick a classifier
clf = Supervised()
clf = clf.linear_regression()


# Preformat the dataset
# (features, labels) = train_test_split(_data)


# Train the model with 70/30 Ratio
# Save the model