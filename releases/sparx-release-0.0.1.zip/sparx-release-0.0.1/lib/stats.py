"""
A collection of statistical routines.

In all functions, `series` can be a `numpy` array or a regular list.
(Internally, it's converted into a `numpy` array.)
"""
import time
from datetime import datetime
import colorsys
import numpy
import scipy.stats
import collections
from dateutil.parser import parse
import color
import warnings
try:
    import pandas as pd
except ImportError:
    pd = None
nanmean = scipy.stats.nanmean

def sorted(data, reversed = False, **args):
    """
        sorted
        ------
        Same as data.sort(...), except that it
            - does not sort the original array
            - returns a sorted copy
            - with a `reversed` provision
    
        This works only with `numpy`-like arrays that support `argsort`
        """
    indices = data.argsort(**args)
    if reversed:
        return data[indices[::-1]]
    return data[indices]



def _slow_uniq(seq):
    """
        uniq
        ----
        Returns a unique list of elements from a sequence, preserving order.
        [source](http://stackoverflow.com/a/480227/100904)
    
        If you are using a NumPy array and are OK with sorted return values, use
        `numpy.unique` instead. It's faster.
    
            >>> _slow_uniq(['c','c','b','b','b','a','a'])
            ['c', 'b', 'a']
    
        """
    seen = set()
    seen_add = seen.add
    return [ x for x in seq if x not in seen if not seen_add(x) ]


uniq = pd.unique if pd is not None else _slow_uniq

def freq(seq):
    """
        freq
        ----
        Returns a dictionary containing the number of occurrences of
        each iteq in a sequence. Order is not preserved.
        [source](http://stackoverflow.com/a/4037497/100904)
    
            >>> freq(['c','c','b','b','b','a','a'])
            {'a': 2, 'c': 2, 'b': 3}
        """
    d = collections.defaultdict(int)
    for item in seq:
        d[item] += 1

    return dict(d)



def rolling_window(series, window):
    """
        rolling_window
        --------------
        Returns a rolling window. For example:
    
            >>> rolling_window([1,2,3,4], window=3)
            array([[ nan,  nan,   1.],
                   [ nan,   1.,   2.],
                   [  1.,   2.,   3.],
                   [  2.,   3.,   4.]])
    
        This is useful in computing moving averages.
        For example, this gives you the 7-day moving average:
    
            numpy.mean(rolling_window(data, 7))
    
        References:
    
        - [Rolling statistics](http://www.rigtorp.se/2011/01/01/rolling-statistics-numpy.html)
        - [Using strides for an efficient moving average filter](http://stackoverflow.com/questions/4936620/using-strides-for-an-efficient-moving-average-filter)
        """
    fill = numpy.empty(window - 1)
    fill.fill(numpy.nan)
    series = numpy.concatenate([fill, series, fill])
    shape = series.shape[:-1] + (series.shape[-1] - 2 * window + 2, window)
    strides = series.strides + (series.strides[-1],)
    return numpy.lib.stride_tricks.as_strided(series, shape=shape, strides=strides)



def movingaverage(series, period):
    """
        movingaverage
        -------------
        Returns a new series with the moving average over the same period.
    
        The length of the new series is the same as the original.
        If there are any nan values in the past, they're ignored.
    
            >>> movingaverage([2,3,numpy.nan,numpy.nan,6], 2)
            array([ 2. ,  2.5,  3. ,  nan,  6. ])
        """
    return nanmean(rolling_window(series, period), -1)



def quantiles(series, quantiles = [0.0,
 0.25,
 0.5,
 0.75,
 1.0]):
    """
        quantiles
        ---------
        Returns the specified quantiles of a series, ignoring nan.
        In pandas, use `Series.quantile` instead.
    
            >>> quantiles(numpy.arange(1,999),[0.,.33,.67,1.])
            array([  1, 330, 668, 998])
        """
    series = series[(-numpy.isnan(series))]
    if len(series) == 0:
        return numpy.zeros(len(quantiles))
    count = numpy.ma.count(series) - 1
    indices = (numpy.array(quantiles) * count).astype(int)
    return numpy.array(sorted(series))[indices]



def scale(series, lo = None, hi = None):
    """
        scale
        -----
        Returns the values scaled from 0 - 1.
        If lo/hi are specified, they are scaled from 0 - 1 instead of min/max
    
            >>> scale([1,2,3,4,5])
            array([ 0.  ,  0.25,  0.5 ,  0.75,  1.  ])
        """
    series = numpy.array(series, dtype=float)
    lo = numpy.nanmin(series) if lo is None else lo
    lo = 0 if numpy.isnan(lo) else lo
    hi = numpy.nanmax(series) if hi is None else hi
    hi = 0 if numpy.isnan(lo) else hi
    return (series - lo) / (hi - lo or numpy.nan)



def rank(series):
    """
        rank
        ----
        **Deprecated**. Use `pd.Series.rank(method='min', ascending=False)` instead
    
        Returns the [competition rank](http://en.wikipedia.org/wiki/Ranking#Standard_competition_ranking_.28.221224.22_ranking.29)
        of each element in a numeric array. Differs from scipy.stats.mstats.rank
        if the values are identical: the lowest (i.e. best) rank is given to all
        of them.
    
            >>> rank([3,4,4,5,5,8])
            array([6, 4, 4, 2, 2, 1])
        """
    (i, rank,) = (0, {})
    a = numpy.array(series, dtype=float)
    a.sort()
    for x in a[(~numpy.isnan(a))][::-1]:
        if numpy.isnan(x):
            continue
        if x not in rank:
            rank[x] = i + 1
        i += 1

    return numpy.array([ rank.get(x, numpy.nan) for x in series ])



def corrcoef(metrics):
    """
        corrcoef
        --------
        Same as numpy.ma.corrcoef, but returns p values as well
    
            >>> corrcoef([
            ...     [1,2,3],
            ...     [2,3,4],
            ...     [3,numpy.nan,5]])
            Cor(cor=array([[ 1.,  1.,  1.],
                   [ 1.,  1.,  1.],
                   [ 1.,  1.,  1.]]), prob=array([[ 0.,  0.,  0.],
                   [ 0.,  0.,  0.],
                   [ 0.,  0.,  0.]]))
        """
    masked = numpy.ma.masked_array(metrics, numpy.isnan(metrics))
    r = numpy.ma.corrcoef(masked)
    df = masked.shape[0] - 2
    t_squared = r * r * (df / ((1.0 - r) * (1.0 + r)))
    prob = scipy.stats.mstats.betai(0.5 * df, 0.5, df / (df + t_squared))
    prob[r == 1.0] = 0.0
    Cor = collections.namedtuple('Cor', ['cor', 'prob'])
    return Cor(r.filled(0.0), prob.filled(1.0))



def crosstab(row, col, val, rowsum = False, colsum = False):
    """
        crosstab
        --------
        Checks how significantly cell averages differ from column averages.
    
        Inputs:
    
        - row: array of size N of row labels, e.g. department name
        - col: array of size N of column labels, e.g. question name
        - val: array of size N of values, e.g. score for the department in a question
        TODO: rowsum, colsum
    
        Returns:
    
        - rows: row headers. Includes total row if `rowsum` is True
        - cols: column headers. Includes total column if `colsum` is True
        - mean[row, col]: mean of values
        - diff[row, col]: deviation of crosstab from total row
        - prob[row, col]: signficance of the above deviation. Smaller is more significant
    
        TODO: Handle `nan`s
    
            >>> crosstab(
            ...     ['A','A','A','B','B','B'],
            ...     ['X','Y','X','Y','X','Y'],
            ...     [ 1 , 2 , 3 , 4 , 5 , 6 ])
            Crosstab(rows=array(['A', 'B'], dtype=object), cols=array(['X', 'Y'], dtype=object), mean=array([[ 2.,  2.],
                   [ 5.,  5.]]), diff=array([[-1., -2.],
                   [ 2.,  1.]]), prob=array([[ 0.5,  nan],
                   [ nan,  0.5]]))
        """
    (row, col, val,) = (numpy.array(row), numpy.array(col), numpy.array(val))
    (rows, cols,) = (uniq(row), uniq(col))
    shp = (len(rows), len(cols))
    (mean, diff, prob,) = (numpy.zeros(shp), numpy.zeros(shp), numpy.ones(shp))
    row_indices = dict(((r, row == r) for r in rows))
    col_indices = dict(((c, col == c) for c in cols))
    for (ci, c,) in enumerate(cols):
        row_mean = nanmean(val[col_indices[c]])
        for (ri, r,) in enumerate(rows):
            v = val[(row_indices[r] & col_indices[c])]
            mean[ri, ci] = nanmean(v)
            diff[ri, ci] = mean[ri, ci] - row_mean
            prob[ri, ci] = scipy.stats.ttest_1samp(v, row_mean)[1]


    Crosstab = collections.namedtuple('Crosstab', ['rows',
     'cols',
     'mean',
     'diff',
     'prob'])
    return Crosstab(rows, cols, mean, diff, prob)



def timeseries(dates, *value, **args):
    """
        timeseries
        ----------
        Given a set of dates and one or more array values,
        adds `nan`s to the values for all missing days.
    
        Takes an optional `start_date=datetime.datetime(...)`
        to override the start date.
    
        Returns a Timeseries object that has two attributes:
    
        - dates: the start date of the dates (min of dates)
        - result: numpy matrix with rows same as value, columns being
                  each *consecutive* day.
    
            >>> timeseries(
            ...     ['10 Aug 2012', '12 Aug 2012', '13 Aug 2012'],
            ...     [3,4,5],
            ...     [4,5,6])
            Timeseries(dates=datetime.datetime(2012, 8, 10, 0, 0), series=array([[  3.,  nan,   4.,   5.],
                   [  4.,  nan,   5.,   6.]]))
        """
    dates = [ parse(date) for date in dates ]
    start_date = args.get('start_date', min(dates))
    max_date = max(dates)
    num_days = (max_date - start_date).days + 1 if max_date >= start_date else 0
    result = numpy.empty([len(value), num_days])
    result.fill(numpy.nan)
    if num_days > 0:
        for (i, array,) in enumerate(value):
            for (j, v,) in enumerate(array):
                result[i, (dates[j] - start_date).days] = v


    Timeseries = collections.namedtuple('Timeseries', ['dates', 'series'])
    return Timeseries(start_date, result)



def growth(series, period, ratio = True):
    """
        growth
        ------
        Returns the growth of a series over a period. For example,
    
            >>> # mean(4,3)/mean(2,1) - 1
            >>> round(growth([1,2,3,4], 2), 5)
            1.33333
    
        If ratio is false, just returns the difference
    
            >>> growth([1,2,3,4], 2, ratio=False) # 3.5 - 1.5
            2.0
        """
    (v2, v1,) = (nanmean(series[(-period):]), nanmean(series[(-2 * period):(-period)]))
    if ratio:
        return v2 / v1 - 1
    return v2 - v1



def rising(series, period):
    """
        rising
        ------
        Returns whether a series has been steadily rising or falling over the last
        `period` periods. +1 indicates steadily rising,
        -1 indicates steadily falling, 0 indicates neither.
    
            >>> rising(numpy.array([0,1,2,3,4]), 4)
            1
            >>> rising(numpy.array([5,4,3,2,1]), 4)
            -1
            >>> rising(numpy.array([0,1,2,1,2]), 4)
            0
        """
    if len(series) < period + 1:
        return 0
    (present, past,) = (series[(-period):], series[(-period - 1):-1])
    if (present > past).all():
        return +1
    if (present < past).all():
        return -1
    return 0



def smooth(points, precision = 6, start = 'M'):
    """
        smooth
        ------
        Returns the `d` attibute of a smooth bezier path through the points.
        Creates a Catmull-Rom spline.
    
            <path d="{{! stats.smooth([(10, 10), (20, 20), (10, 30), (30, 40)]) }}"/>
        """
    formatstring = '%0.' + str(precision) + 'f %0.' + str(precision) + 'f'

    def format(a, b):
        return formatstring % (a, b)


    d = [start, format(points[0][0], points[0][1])]
    last_but_two = len(points) - 2
    for (i, (x, y,),) in enumerate(points[:-1]):
        if i == 0:
            offsets = [0, 0, 1, 2]
        elif i == last_but_two:
            offsets = [-1, 0, 1, 1]
        else:
            offsets = [-1, 0, 1, 2]
        p = [ points[(i + offset)] for offset in offsets ]
        d += ['C' + format((-p[0][0] + 6 * p[1][0] + p[2][0]) / 6.0, (-p[0][1] + 6 * p[1][1] + p[2][1]) / 6.0), format((p[1][0] + 6 * p[2][0] - p[3][0]) / 6.0, (p[1][1] + 6 * p[2][1] - p[3][1]) / 6.0), format(p[2][0], p[2][1])]

    return ' '.join(d)



def decimals(data):
    """
        decimal
        -------
        Given a series of numbers, returns the number of decimals
        *just enough* to differentiate between most numbers.
    
        Usage:
    
            >>> decimals([1,2,3])
            0
            >>> decimals([.1,.2,.3])
            1
            >>> decimals([.01,.02,.3])
            2
            >>> decimals(.01)
            2
        """
    series = numpy.ma.masked_array(data, mask=numpy.isnan(data))
    series = series.reshape((series.size,))
    diffs = numpy.diff(series[series.argsort()])
    diffs = diffs[(diffs > 1e-10)]
    if len(diffs) > 0:
        smallest = numpy.nanmin(diffs.filled(numpy.Inf))
    else:
        nonnan = series.compressed()
        smallest = abs(nonnan[0]) or 1 if len(nonnan) > 0 else 1
    return int(max(0, numpy.floor(0.999999 - numpy.log10(smallest))))



def format(data, comma = False):
    """
    format
    ------
    Returns data formatted with **just enough** decimals
    """
    d = decimals(data)
    if comma:
        format = '{:,.%df}' % d
    else:
        format = '{:.%df}' % d
    if hasattr(data, '__iter__'):
        return [ format.format(float(v)) for v in data ]
    else:
        return format.format(data)



def opacity(prob, method = 'stars'):
    """
        opacity
        -------
        Returns an opacity value given a probability.
    
        Here are the possible methods:
        - stars: nil = 25%, * (.05) = 50%, ** (.01) = 75%, *** (.001) = 100%
        """
    if method.lower().startswith('star'):
        if prob > 0.05:
            return 0.25
        if prob > 0.01:
            return 0.5
        if prob > 0.001:
            return 0.75
        return 1.0
    return 1 - prob



def round_near(v):
    """
        round_near
        ----------
        Returns the nearest multiple of 2, 5 or 10 near the POSITIVE number
    
        Usage:
    
            >>> round_near(1.4)
            1
            >>> round_near(3.8)
            5
            >>> round_near(.094)
            0.1
            >>> round_near(30)
            20.0
            >>> round_near(numpy.inf)
            inf
            >>> round_near(numpy.nan)
            nan
        """
    if v == 0 or not numpy.isfinite(v) or numpy.isnan(v):
        return v
    if v < 0:
        v = -v
        sign = -1
    else:
        sign = +1
    n = 1
    while v > 10:
        v /= 10.0
        n *= 10.0

    while v < 1:
        v *= 10.0
        n /= 10.0

    return sign * n * (1 if v < 1.5 else 2 if v < 3.5 else 5 if v < 7.5 else 10)



def ticks(series, count):
    """
        ticks
        -----
        Returns approximately `count` uniform values *within* the series.
        Typically used to plot axis ticks for the series.
    
        Usage:
    
            >>> ticks([0, 100], 5)
            array([   0.,   20.,   40.,   60.,   80.,  100.])
            >>> ticks([13, 39], 5)
            array([ 15.,  20.,  25.,  30.,  35.])
            >>> ticks([46, 47], 5)
            array([ 46. ,  46.2,  46.4,  46.6,  46.8,  47. ])
        """
    series = numpy.array(series)
    (hi, lo,) = (numpy.nanmax(series), numpy.nanmin(series))
    interval = round_near((hi - lo) / float(count))
    shift = lo % interval
    start = lo if shift == 0 else lo + interval - shift
    return numpy.arange(start, hi + 1e-10, interval)



def andjoin(strings, sep = ', ', last = ' and '):
    """
        andjoin
        -------
        Returns a series of strings joined by comma, except the last one
        which is joined by 'and'.
    
        Usage:
    
            >>> andjoin(['red', 'blue', 'green'])
            'red, blue and green'
            >>> andjoin(['red', 'blue', 'green'], sep=' or ', last=None)
            'red or blue or green'
        """
    strings = list(strings)
    if not last:
        return sep.join(strings)
    else:
        if len(strings) > 2:
            strings = list(strings)
            return sep.join(strings[:-1]) + last + strings[-1]
        return last.join(strings)



class Map:
    """
        Map
        ---
        Map creates transformations functions and their inverses.
    
        Usage:
    
            >>> g = Map([0, .2, .5], ['#f00', '#ff0', '#fff'])
            >>> g(.1) # returns midpoint of #f00 and #ff0
            '#ff7f00'
            >>> g.invert('#ff0')
            0.2
    
        TODO:
        - Log scale
        """


    def __init__(self, domain, range, clamp = False, power = 1, nice = False):
        self.domain = list(domain)
        self.range = list(range)
        self.clamp = clamp
        self.power = power
        self._find_domain = self._find_forward if self.domain[0] <= self.domain[-1] else self._find_reverse
        self._find_range = self._find_forward if self.range[0] <= self.range[-1] else self._find_reverse
        (self.t2d, self.d2t,) = self._map_functions(domain[0])
        (self.t2r, self.r2t,) = self._map_functions(range[0])



    def _map_functions(self, value):
        """Find type(`value`) and return its map and inverse functions"""
        try:
            float(value)
            return (self._number, self._invert_number)
        except:
            pass
        try:
            color.rgba(value)
            return (self._color, self._invert_color)
        except:
            pass
        try:
            time.mktime(value.timetuple())
            return (self._date, self._invert_date)
        except:
            pass
        return (self._discrete, self._invert_discrete)



    def _find_forward(self, v, s, clamp = False):
        """
                _find_forward(4,8,[4,5,6,6,7,7,5,9,3])
        
                output =(6, 8)
                """
        i = 0
        while i + 2 < len(s) and v > s[(i + 1)]:
            i += 1

        if clamp:
            v = s[0] if v < s[0] else s[-1] if v > s[-1] else v
        return (i, v)



    def _find_reverse(self, v, s, clamp = False):
        """
                    _find_reverse(4,8,[4,5,6,6,7,7,5,9,3])
        
                output =(7, 8)
                """
        i = len(s) - 2
        while i > 0 and v > s[i]:
            i -= 1

        if clamp:
            v = s[0] if v > s[0] else s[-1] if v < s[-1] else v
        return (i, v)



    def __call__(self, v):
        (i, v,) = self._find_domain(v, self.domain, self.clamp)
        t = self.d2t(self.domain[i], self.domain[(i + 1)], v)
        return self.t2r(self.range[i], self.range[(i + 1)], t ** self.power)



    def invert(self, v):
        (i, v,) = self._find_range(v, self.range)
        t = self.r2t(self.range[i], self.range[(i + 1)], v)
        return self.t2d(self.domain[i], self.domain[(i + 1)], t ** (1 / self.power))



    @staticmethod
    def _number(a, b, t):
        """
            _number(3,9,1)
            output = 9
        """
        return a + (b - a) * t



    @staticmethod
    def _invert_number(a, b, x):
        """
            _invert_number(3,9,1)
            output = -1
        """
        return float(x - a) / (b - a)



    @staticmethod
    def _color(a, b, t):
        """Interpolate in the HSL color space. TODO: Use HCL, and fall back to HSL"""
        (ca, cb,) = (color.hsla(a), color.hsla(b))
        c = list((Map._number(va, vb, t) for (va, vb,) in zip(ca, cb)))
        if not -0.5 < ca[0] - cb[0] < 0.5:
            ha = ca[0] - 1 if ca[0] > 0.5 else ca[0]
            hb = cb[0] - 1 if cb[0] > 0.5 else cb[0]
            c[0] = Map._number(ha, hb, t) % 1.0
        else:
            c[0] = c[0] % 1.0
        if ca[1] == 0:
            c[0] = cb[0]
        elif cb[1] == 0:
            c[0] = ca[0]
        for n in range(1, 4):
            c[n] = 0 if c[n] < 0 or numpy.isnan(c[n]) else 1 if c[n] > 1 else c[n]

        return color.name(*(colorsys.hsv_to_rgb(c[0], c[1], c[2]) + (c[3],)))



    @staticmethod
    def _invert_color(a, b, x):
        """Uninterpolate the hue. If that's the same, use lightness. Then saturation"""
        (ca, cb, cx,) = (color.hsla(a), color.hsla(b), color.hsla(x))
        if ca[0] != cb[0]:
            return Map._invert_number(ca[0], cb[0], cx[0])
        else:
            if ca[2] != cb[2]:
                return Map._invert_number(ca[2], cb[2], cx[2])
            return Map._invert_number(ca[1], cb[1], cx[1])



    @staticmethod
    def _date(a, b, t):
        t_a = time.mktime(a.timetuple())
        t_b = time.mktime(b.timetuple())
        x = t_a + (t_b - t_a) * t
        return datetime.fromtimestamp(x)



    @staticmethod
    def _invert_date(a, b, x):
        t_a = time.mktime(a.timetuple())
        t_b = time.mktime(b.timetuple())
        t_x = time.mktime(x.timetuple())
        return (t_x - t_a) / (t_b - t_a)



    @staticmethod
    def _discrete(a, b, t):
        if t < 0.5:
            return a
        return b



    @staticmethod
    def _invert_discrete(a, b, x):
        if x == a:
            return 0
        if x == b:
            return 1
        raise ValueError('Invalid value')




def groupmeans(group, value):
    """
        groupmeans
        ----------
        **Deprecated**. Use autolyse.groupmeans instead
    
        Checks if the group-wise averages are significantly different.
    
        Inputs:
    
        - group: array of size N of group names, e.g. department
        - value: array of size N of values, e.g. sales
    
        Outputs:
    
        - keys: sorted unique list of group names
        - means: average value for each group
        - counts: counts for each group
        - prob: probability that the means are the same
        """
    warnings.warn('Use autolyse.groupmeans instead of stats.groupmeans', FutureWarning, stacklevel=2)
    group = numpy.array(group)
    value = numpy.ma.masked_array(value, numpy.isnan(value))
    keys = numpy.unique(group)
    arrays = [ value[(group == key)] for key in keys ]
    means = numpy.array([ nanmean(v) for v in arrays ])
    counts = numpy.array([ len(v) for v in arrays ])
    (F, prob,) = scipy.stats.mstats.f_oneway(*arrays)
    Groupmeans = collections.namedtuple('Groupmeans', ['keys',
     'means',
     'counts',
     'prob'])
    return Groupmeans(keys, means, counts, prob)



def hierarchify(data, keys, metrics):
    """
        hierarchify
        -----------
        **Deprecated**. Use layout.SubTreemap instead
    
        Usage:
    
            T('treemap.svg', width=100, height=100,
               size=lambda x:sum(x['size']),
               **hierarchify(data,
                    keys=['Zone','Distr'],
                    metrics=['size','count']))
    
        Output structure:
    
            [{
                'Zone': 'value',
                'size': [v1, v2, v3, ... for each children],
                'count': [v1, v2, v3, ... for each children],
                'children': [
                    {
                        'Zone': 'value',
                        'Distr': 'value',
                        'size': [v1],
                        'count': [v1],
                    },
                    {
                        'Zone': 'value',
                        'Distr': 'value',
                        'size': [v1],
                        'count': [v1],
                    },
                    ...
                ]
            }, ...]
        """
    warnings.warn('Use layout.SubTreemap instead of stats.hierarchify', FutureWarning, stacklevel=2)
    out = collections.OrderedDict()
    keyrange = range(0, len(keys))
    for row in data:
        node = out
        for nkey in keyrange:
            node = node.setdefault('children', collections.OrderedDict()).setdefault(row[keys[nkey]], collections.OrderedDict())
            for k in xrange(0, nkey + 1):
                node[keys[k]] = row[keys[k]]

            for m in metrics:
                node.setdefault(m, []).append(row[m])



    return {'data': out['children'].values(),
     'children': lambda x: (x['children'].values() if 'children' in x else None)}


if __name__ == '__main__':
    N = numpy.nan

    def eq(a, b):
        return abs(a - b) < 1e-10



    def alleq(a, b):
        for (x, y,) in zip(a, b):
            if abs(x - y) > 1e-10 and not (numpy.isnan(x) and numpy.isnan(y)):
                return False

        return True


    assert eq(1, nanmean([1, N, N]))
    assert eq(1.5, nanmean([1, N, 2]))
    assert numpy.isnan(nanmean([]))
    assert numpy.isnan(nanmean([N]))
    data = [1,
     2,
     3,
     N,
     5]
    assert alleq(movingaverage(data, 3), numpy.array([1.0,
     1.5,
     2.0,
     2.5,
     4.0]))
    m = movingaverage([N, 1, N], 3)
    assert numpy.isnan(m[0])
    assert alleq(m[1:], [1, 1])
    assert alleq(quantiles(numpy.arange(1, 101)), [1,
     25,
     50,
     75,
     100])
    assert alleq(scale([2, 3, 4]), [0, 0.5, 1])
    assert numpy.isnan(scale([2, 2, 2])).all()
    assert rising(numpy.array([0,
     1,
     2,
     3,
     4]), 4) == +1
    assert rising(numpy.array([5,
     4,
     3,
     2,
     1]), 4) == -1
    assert rising(numpy.array([0,
     1,
     2,
     1,
     2]), 4) == 0
    m = Map([0, 10.0], [0, 1.0])
    assert m(3) == 0.3
    assert m.invert(0.5) == 5
    m = Map([0.0, 1.0], ['#f00', '#0f0'])
    assert m(0.5) == '#ff0'
    m = Map([0, 10.0, 20.0], [0, 0.5, 2.0])
    assert abs(m(-4) - -0.2) < 1e-10
    assert abs(m.invert(m(-4)) + 4) < 1e-10
    assert abs(m(4) - 0.2) < 1e-10
    assert abs(m(12) - 0.8) < 1e-10
    assert abs(m(24) - 2.6) < 1e-10
    m = Map([20.0, 10.0, 0], [2.0, 0.5, 0])
    assert abs(m(-10) - -0.5) < 1e-10
    assert abs(m(4) - 0.2) < 1e-10
    assert abs(m(12) - 0.8) < 1e-10
    assert abs(m(24) - 2.6) < 1e-10
    m = Map([20.0, 10.0, 0], [0, 0.5, 2.0])
    assert abs(m(-10) - 3.5) < 1e-10
    assert abs(m.invert(3.5) - -10) < 1e-10
    assert abs(m.invert(m(-10)) + 10) < 1e-10
    m = Map([20.0, 10.0, 0], [0, 0.5, 2.0], clamp=True)
    assert abs(m(-10) - 2) < 1e-10
    assert abs(m(20) - 0) < 1e-10
    assert abs(m.invert(3.5) - -10) < 1e-10
    m = Map([20.0, 10.0, 0], [0, 0.5, 2.0], power=0.5)
    assert abs(m.invert(m(4)) - 4) < 1e-10
    assert abs(m.invert(m(-10)) + 10) < 1e-10
    m = Map([1.0, 8.0], [datetime(2012, 1, 1), datetime(2012, 1, 8)])
    assert m(1) == datetime(2012, 1, 1)
    assert m(8) == datetime(2012, 1, 8)
    assert m(4) == datetime(2012, 1, 4)
    assert m(3.5) == datetime(2012, 1, 3, 12, 0, 0)
    m = Map(['a', 'b', 'c'], ['A', 'B', 'C'])
    assert m('a') == 'A'
    assert m('b') == 'B'
    assert m('c') == 'C'
    assert m.invert('A') == 'a'
    assert m.invert('B') == 'b'
    assert m.invert('C') == 'c'
    try:
        print m('d')
    except ValueError:
        pass
    assert alleq(rank([10,
     40,
     15,
     15]), [4,
     1,
     2,
     2])
    assert alleq(rank([10,
     40,
     N,
     15,
     15,
     15]), [5,
     1,
     N,
     2,
     2,
     2])
    import doctest
    doctest.testmod()
