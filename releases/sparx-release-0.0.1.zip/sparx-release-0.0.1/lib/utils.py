import six
import numpy

def attrs(attrs, defaults = None, value = None, index = None):
    """
    Returns a set of XML/HTML attributes from a dictionary.
    
    Parameters
    ----------
    attrs: dict
        Keys are HTML attribute names.
        Values are HTML attribute values.
        Values can be functions. For example,
        ``{'fill': lambda value, index: ... }``
    
    If this form is used, the ``value`` and ``index`` are passed for each
    element of the visualisation. For example, in a jitter map, each circle's
    attributes can be coloured based on its value or index.
    """
    final = dict(defaults or {})
    final.update(attrs or {})

    def getval(val, attr):
        if hasattr(val, '__call__'):
            return six.text_type(val(value, index))
        else:
            return six.text_type(val)

    attrstr = []
    for attr, val in six.iteritems(final):
        v = getval(val, attr)
        if v is not None:
            attrstr.append(six.text_type(attr + '="' + v + '"'))

    return six.text_type(' '.join(attrstr))


def common_params(_):
    data = _('data')
    return (_('x', 0),
     _('y', 0),
     float(_('lo', numpy.nanmin(numpy.array(data, dtype=float)))),
     float(_('hi', numpy.nanmax(numpy.array(data, dtype=float)))))


def extract(data, param):
    """
    Extracts the param(eter) from data.
    
    If param is callable, it's just applied on each row of data.
    
    If it's a member of the first row of data (as a dictionary or array),
    that item is returned for every row.
    
    Examples
    --------
    This is how ``extract`` behaves::
    
        extract([(1, 1), (2, 2)], 1)        # [1, 2]
        extract([(1, 1), (2, 2)], '1')      # ['1', '1']
        extract([1, 2, 3], None)            # [1, 2, 3]
        extract([{'a': 1, 'b': 2},
                 {'a': 3, 'b': 4}], 'a')    # [1, 3]
    """
    if six.callable(param):
        return [ param(data) for row in data ]
    elif param is None:
        return data
    elif hasattr(data[0], '__len__') and type(param) is int and 0 <= param < len(data):
        return [ row[param] for row in data ]
    elif isinstance(param, six.string_types) and param in data[0]:
        return [ row.get(param, numpy.nan) for row in data ]
    else:
        return [ param for row in data ]
