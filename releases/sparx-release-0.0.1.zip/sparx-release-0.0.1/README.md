# LitmusBi
LitmusBi-Server is a advanced big data predictive analytic and visualization engine.

### Features
* Built-in Visualization
* Machine Learning Simplified
* Customization
* Sharing 
* Reports & Insights