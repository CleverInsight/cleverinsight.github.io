# Credentials can be generates via Twitter's Application Management:             
#   https://apps.twitter.com/app/new 
consumer_key = "CyCbMGTTsAvpsrqpfFkCm3rdg"                                       
consumer_secret = "LriErTNvjvKHO0HhlCptArObwUx27MUzVGniSlFcaIlXvzZ8uo"           
access_key = "169407054-QCrbH41WX6fCBvWV9Tkmyr4nXUXAZZLw516Ke344"                
access_secret = "9cjQk7Gl4Ii5zrxuX4j461vVKhep5EqtJ84lyZIcIwjK8" 